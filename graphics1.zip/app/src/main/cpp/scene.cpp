#include "scene.h"

#include "obj_teapot.h"
#include "tex_flower.h"

Shader* Scene::vertexShader = nullptr;
Shader* Scene::fragmentShader = nullptr;
Program* Scene::program = nullptr;
Camera* Scene::camera = nullptr;
Light* Scene::light = nullptr;
Object* Scene::teapot = nullptr;
Material* Scene::flower = nullptr;

void Scene::setup(AAssetManager* aAssetManager) {

    // set asset manager
    Asset::setManager(aAssetManager);

    // create shaders
    vertexShader = new Shader(GL_VERTEX_SHADER, "vertex.glsl");
    fragmentShader = new Shader(GL_FRAGMENT_SHADER, "fragment.glsl");

    // create program
    program = new Program(vertexShader, fragmentShader);

    // create camera
    camera = new Camera(program);
    camera->eye = vec3(60.0f, 00.0f, 0.0f);
    camera->updateCameraUVN();

    // create light
    light = new Light(program);
    light->position = vec3(100.0f, 0.0f, 0.0f);

    // create floral texture
    flower = new Material(program, texFlowerData, texFlowerSize);

    // create teapot object
    teapot = new Object(program, flower, objTeapotVertices, objTeapotIndices,
                        objTeapotVerticesSize, objTeapotIndicesSize);

    //////////////////////////////
    /* TODO: Problem 2.
     *  Scale the teapot by 2.0 along the y-axis.
     *  Rotate the teapot by 90° CW about the rotation axis defined by two points
     *  (0, 0, 10) → (10, 0, 20).
     */

    mat4 scaleM, rotMat;
    scaleM = transpose(mat4(1.0f, 0.0f, 0.0f, 0.0f,  // In OpenGL, the matrix must be transposed
                            0.0f, 2.0f, 0.0f, 0.0f,
                            0.0f, 0.0f, 1.0f, 0.0f,
                            0.0f, 0.0f, 0.0f, 1.0f));

    rotMat =transpose(          mat4(1.0f, 0.0f, 0.0f, 10.0f,
                                0.0f, 1.0f, 0.0f, 0.0f,
                                0.0f, 0.0f, 1.0f, 0.0f,
                                0.0f, 0.0f, 0.0f, 1.0f)
                                *

                                mat4(cos(radians(45.0)), 0.0f,sin(radians(45.0)), 0.0f, //x축에 맞춤
                                     0.0f,1.0f, 0.0f, 0.0f,
                                     -sin(radians(45.0)) , 0.0f, cos(radians(45.0)), 0.0f,
                                     0.0f, 0.0f, 0.0f, 1.0f)
                                *

                                mat4(1.0f, 0.0f, 0.0f, 0.0f,  //x축 중심 회전 -90도,cw
                                     0.0f, cos(radians(-90.0)), -sin(radians(-90.0)), 0.0f,
                                     0.0f, sin(radians(-90.0)), cos(radians(-90.0)), 0.0f,
                                     0.0f, 0.0f, 0.0f, 1.0f)
                                *
                                mat4(cos(radians(-45.0)), 0.0f,sin(radians(-45.0)), 0.0f,
                                     0.0f,1.0f, 0.0f, 0.0f,
                                     -sin(radians(-45.0)) , 0.0f, cos(radians(-45.0)), 0.0f,
                                     0.0f, 0.0f, 0.0f, 1.0f)
                                     *
                                        mat4(1.0f, 0.0f, 0.0f, -10.0f,
                                             0.0f, 1.0f, 0.0f, 0.0f,
                                             0.0f, 0.0f, 1.0f, 0.0f,
                                             0.0f, 0.0f, 0.0f, 1.0f)
    );

    teapot->worldMatrix = rotMat * scaleM;
    //////////////////////////////
}

void Scene::screen(int width, int height) {

    // set camera aspect ratio
    camera->aspect = (float) width / height;
}

void Scene::update(float deltaTime) {
   /* static float time = 0.0f;
    time += deltaTime;*/
    // use program
    program->use();

    //////////////////////////////
    /* TODO: Problem 3.
     *  Rotate the teapot about the z-axis.
     */

     teapot->worldMatrix = transpose(mat4(
             cos(deltaTime), -sin(deltaTime), 0,0,
             sin(deltaTime), cos(deltaTime), 0,0,
             0, 0, 1,0,
             0,0,0,1
                                     )) * teapot->worldMatrix
     ;
    //////////////////////////////


    camera->updateViewMatrix();
    camera->updateProjectionMatrix();
    light->setup();


    // draw teapot
    teapot->draw();
}

void Scene::rotateCamera(float dx,float dy) {
    float rotationSensitivity = 0.03;

    float thetaYaw=glm::radians(rotationSensitivity*dx);
    float thetaPinch=glm::radians(rotationSensitivity*dy);

    rotateCameraYaw(thetaYaw);
    rotateCameraPitch(thetaPinch);
}

void Scene::rotateCameraYaw(float theta) {

    //////////////////////////////
    /* TODO: Problem 4.
     *  calculate the rotated u,n vector about v axis.
     *  Argument theta is amount of rotation in radians. theta is positive when CCW.
     *  Note that u,v,n should always be orthonormal.
     *  The u vector can be accessed via camera->cameraU.
     *  The v vector can be accessed via camera->cameraV.
     *  The n vector can be accessed via camera->cameraN.
     */

    /*
    glm::vec3 cameraTarget = glm::vec3(0.0f, 0.0f, 0.0f); // AT
    glm::vec3 UP = glm::vec3(0.0f, 1.0f, 0.0f); // UP
    glm::vec3 cameraDirection = glm::normalize(camera->eye - cameraTarget);  // n벡터 EYE-AT
    glm::vec3 cameraRight = glm::normalize(glm::cross(cameraDirection, UP)); // u벡터 n X up , up은 축과 동일하게 설정
    glm::vec3 cameraUp = glm::normalize(glm::cross(cameraDirection, cameraRight)); // v = n x u
    */

    //camera space 에서 y축을 기준으로 나머지 두 축을 움직여줘야 한다.

    mat3 rot = transpose(mat3 (
            cos(theta), 0, sin(theta), // 마우스 스크롤이 물체 방향과 같이 움직임 ->각도의 부호 바뀜
            0, 1, 0,
            -sin(theta),0,cos(theta)
    ));

    camera->cameraU = rot * camera->cameraU;
    camera->cameraN = rot * camera->cameraN;


    camera->updateViewMatrix();
    //////////////////////////////
}

void Scene::rotateCameraPitch(float theta) {

    //////////////////////////////
    /* TODO: Problem 4.
     *  calculate the rotated v,n vector about u axis.
     *  Argument theta is amount of rotation in radians. Theta is positive when CCW.
     *  Note that u,v,n should always be orthonormal.
     *  The u vector can be accessed via camera->cameraU.
     *  The v vector can be accessed via camera->cameraV.
     *  The n vector can be accessed via camera->cameraN.
     */

    mat3 rot = transpose(mat3 (
            cos(-theta), -sin(-theta), 0, // 마우스 스크롤이 물체 방향과 같이 움직임 ->각도의 부호 바뀜
            sin(-theta), cos(-theta), 0,
            0,0,1
            ));

    camera->cameraV = rot * camera->cameraV;
    camera->cameraN = rot * camera->cameraN;


    camera->updateViewMatrix();
    //////////////////////////////
}

void Scene::translateLeft(float amount) {

    //////////////////////////////
    /* TODO: Problem 4.
     *  Calculate the camera position(eye) when translated left.
     */

    camera->eye += vec3(0.0f, 00.0f, amount);

    camera->updateViewMatrix();
    //////////////////////////////
}

void Scene::translateFront(float amount) {

    //////////////////////////////
    /* TODO: Problem 4.
     *  Calculate the camera position(eye) when translated front.
     */
    camera->eye += vec3(-amount, 00.0f, 0.0f);
    camera->updateViewMatrix();
    //////////////////////////////
}

void Scene::translateRight(float amount) {

    //////////////////////////////
    /* TODO: Problem 4.
     *  Calculate the camera position(eye) when translated right.
     */
    camera->eye += vec3(0.0f, 00.0f, -amount);

    camera->updateViewMatrix();
    //////////////////////////////
}

void Scene::translateBack(float amount) {

    //////////////////////////////
    /* TODO: Problem 4.
     *  Calculate the camera position(eye) when translated back.
     */
    camera->eye += vec3(amount, 00.0f, 0.0f);

    camera->updateViewMatrix();
    //////////////////////////////
}
